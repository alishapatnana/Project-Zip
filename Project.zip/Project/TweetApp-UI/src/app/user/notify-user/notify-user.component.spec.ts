import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotifyUserComponent } from './notify-user.component';

describe('UserComponent', () => {
  let component: NotifyUserComponent;
  let fixture: ComponentFixture<NotifyUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotifyUserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NotifyUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});